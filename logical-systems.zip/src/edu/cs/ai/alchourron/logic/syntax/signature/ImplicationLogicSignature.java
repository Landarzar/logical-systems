package edu.cs.ai.alchourron.logic.syntax.signature;

import edu.cs.ai.alchourron.logic.syntax.Signature;

public interface ImplicationLogicSignature extends Signature {

}
