package edu.cs.ai.alchourron.logic.syntax.terms;

import edu.cs.ai.alchourron.logic.syntax.Signature;

public interface Variable<S extends Signature>   extends Term<S> {

}
