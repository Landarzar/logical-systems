package edu.cs.ai.alchourron.logic.syntax.signature;

import edu.cs.ai.alchourron.logic.syntax.Signature;

/**
 * Describes logics, where there is a special falsum elements of the language
 * @author Kai Sauerwald
 */
public interface FalsumLogicSignature extends Signature {

}
