package edu.cs.ai.alchourron.logic.syntax.signature;

import edu.cs.ai.alchourron.logic.syntax.Signature;

/***
 * 
 * @author Kai Sauerwald
 *
 * @param <M> The type of the modalities
 */
public interface ModalLogicSignature<M> extends Signature {

}
