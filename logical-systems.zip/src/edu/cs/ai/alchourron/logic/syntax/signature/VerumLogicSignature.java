package edu.cs.ai.alchourron.logic.syntax.signature;

import edu.cs.ai.alchourron.logic.syntax.Signature;

/**
 * Describes logics, where there is a special tautology elements of the language
 * @author Kai Sauerwald
 */
public interface VerumLogicSignature extends Signature {

}
