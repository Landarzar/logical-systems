package edu.cs.ai.alchourron.logic.semantics.interpretations;

public class Relation {

}
