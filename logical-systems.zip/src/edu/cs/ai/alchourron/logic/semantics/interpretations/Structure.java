package edu.cs.ai.alchourron.logic.semantics.interpretations;

import edu.cs.ai.alchourron.logic.semantics.Interpretation;
import edu.cs.ai.alchourron.logic.syntax.Signature;

public class Structure<D, S extends Signature> implements Interpretation<S> {

	@Override
	public boolean isMatchingSignature(S signature) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public S getSignature() {
		// TODO Auto-generated method stub
		return null;
	}

}
